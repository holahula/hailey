two sigma AI competition submission

Current Placement: #206 (55.38) 

Rating History:

10.24.18 - #206 (55.38) 

10.23.18 - #439 (46.51) 
