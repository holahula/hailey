
    # You extract player metadata and the updated map metadata here for c