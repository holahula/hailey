two sigma AI competition submission

Current Placement: #206 (55.38) - 10.24.18